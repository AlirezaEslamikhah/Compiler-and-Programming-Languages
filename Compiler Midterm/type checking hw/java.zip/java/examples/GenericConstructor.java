import java.util.ArrayList;
// Use case to ensure that generic constructors work properly
public class GenericConstructor {
    public static void main(String[] args){
        ArrayList<Integer> myList = new ArrayList<>();
    }
}
