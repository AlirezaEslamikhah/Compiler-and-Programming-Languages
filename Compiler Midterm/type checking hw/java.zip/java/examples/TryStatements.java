public class TryStatements {
    public static void main(String[] args){
        try (conContext.inputRecord) {
            System.out.println("text");
        }
    }
}
