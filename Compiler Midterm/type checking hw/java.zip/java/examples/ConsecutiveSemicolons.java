// Use case to ensure that consecutive semicolons
// in package declaration and import declaration work properly

package consecutive.semicolon;;
import java.util.ArrayList;;
import java.util.Collections;

public class ConsecutiveSemi {
}

