//efewfewf kjkwebfuoiewrh eruoifboeruwf uowefgh
class HelloWorld {

    /*mepgip
    ewfe
    ewferwf
    wedf*/
    public static void main(String[] args) {
        System.out.println("Hello, World!"); 
    }
}